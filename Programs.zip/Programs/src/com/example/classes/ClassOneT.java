package com.example.classes;

public class ClassOneT {

	public static void main(String[] args) {
		ClassTwoT.methodOfClassTwo();     // File name must be ClassOneT.java,give file any other name gives compile time error
										 //Run with ClassOneT.java
	}
	
}
class ClassTwoT{
	 static void methodOfClassTwo(){
		 System.out.println("From Class Two");
	 }
	
}

