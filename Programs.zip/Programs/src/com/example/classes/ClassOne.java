package com.example.classes;

class ClassOne {

	public static void main(String[] args) {
		ClassTwo.methodOfClassTwo();     // File can be ClassOne.java or ClassTwo.java or anyname.java
										//Run with ClassOne.java beacuse execution starts from main method
	}
	
}
class ClassTwo{
	 static void methodOfClassTwo(){
		 System.out.println("From Class Two");
	 }
	
}

