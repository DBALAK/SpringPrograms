package com.example.classes;

class ClassTU {

	public static void main(String[] args) {
		ClassOneU.methodOfClassTwo();     // File name must be ClassOneU.java,give file any other name gives compile time error
										 //Run with ClassTU.java
	}
	
	//NOTE: One java file cannot contain more than one public class
}
public class ClassOneU{
	 static void methodOfClassTwo(){
		 System.out.println("From Class Two");
	 }
	
}

