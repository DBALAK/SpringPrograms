package com.search;

import java.util.Scanner;

public class LinearSearchWithRecursion {

	public static void main(String[] args) {
		{
			Scanner s = new Scanner(System.in);

			System.out.print("Enter the size of the array: ");
			int size = s.nextInt();
			System.out.print("Enter an array of numbers: ");

			int[] arr = new int[size];

			for (int i = 0; i < arr.length; i++) {
				arr[i] = s.nextInt();
			}

			System.out.print("Enter the number you want to search: ");
			int search = s.nextInt();
			LinearSearchWithRcrsn access = new LinearSearchWithRcrsn();

			System.out.print("The position of the search item is at array index ");
			access.linearSearch(arr, 0, arr.length, search);
		}

	}

}

class LinearSearchWithRcrsn {

	public void linearSearch(int[] arr, int firstIndex, int lastIndex, int search) {

		if (firstIndex == lastIndex) {  //to check if there is only one element in array
			System.out.println("-1");
		} else {
			if (arr[firstIndex] == search)
				System.out.println(++firstIndex);// to increment postion by 1 as index starts with 0
			else
				linearSearch(arr, firstIndex + 1, lastIndex, search);
		}

	}

}
