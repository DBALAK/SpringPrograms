package com.search;

import java.util.Scanner;

public class LinearSearch {
	public static void main(String[] args) {
		int a[] = { 23, 45, 67, 45, 78 }, flag = 0, i;
		System.out.println("Enter element to search:");
		Scanner s = new Scanner(System.in);
		int noToSearch = s.nextInt();
		for (i = 0; i < a.length; i++) {
			if (a[i] == noToSearch) {
				flag = 1;
				break;
			} else {
				flag = 0;
			}
		}
		if (flag == 1)
			System.out.println("Element " + noToSearch + " found at " + (i + 1) + " position");

		else
			System.out.println("Element is not present");
	}

}
