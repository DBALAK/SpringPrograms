package com.search;

public class BinarySearchWithoutRecursion {

	public static int binarySeacrh(int[] arr, int key) {

		int left, right;
		left = 0;
		right = arr.length - 1;
		while (left <= right) {
			int mid = (left + right) / 2;
			if (key < arr[mid]) {
				right = mid - 1;
			} else if (key == arr[mid]) {
				return mid;
			} else {
				left = mid + 1;
			}
		}
		return -1;
	}
}

class BinaSear {
	public static void main(String[] args) {
		int a[] = { 12, 34, 56, 78, 60 };
		System.out.println(BinarySearchWithoutRecursion.binarySeacrh(a, 60));
	}
}