package com.arrays;

import java.util.Arrays;

public class LargestAndSmallest {

	public static void main(String[] args) {

		int a[] = { 1, 3, 6, 5, 2 }; // 1,2,3,5,6
		Arrays.sort(a);
		System.out.println("Smallest element:" + a[0] + "\t Largest element:" + a[a.length - 1]);
	}

}
