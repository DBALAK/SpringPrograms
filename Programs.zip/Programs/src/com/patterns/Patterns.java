package com.patterns;

public class Patterns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
	    1 
		2 3 
		4 5 6 
		7 8 9 10 
		 */
		int count = 0;
		for (int i = 0; i <= 3; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print((++count) + " ");
			}
			System.out.println();
		}
		/*
	    1 
		1 2 
		1 2 3 
		1 2 3 4 
		1 2 3 4 5
		 */		
		System.out.println();
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++)
			{
				System.out.print(j + " ");
			}
			System.out.println();
		}
		System.out.println();
		/*
		 *
		 **
		 ***
		 ****
		 ******
		 */
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		/*
		 *
		 **
		 ***
		 ****
		 ***
		 **
		 *
		 */

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		for(int i=3;i>=0;i--) {
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		/*
		0
		12
		234
		3456
		45678  */
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print(i + j);
			}
			System.out.println();
		}
		System.out.println();
		/*
	 A A A
	 A A
	 A
	 A A
	 A A A
		 */

		for (int i = 3; i >= 1; i--) 
		{
			for (int j = 1; j <= i; j++)
			{
				System.out.print("A"+" ");
			}
			System.out.println();
		}
		for (int i = 2; i <= 3; i++) 
		{
			for (int j = 1; j <= i; j++)
			{
				System.out.print("A"+" ");
			}
			System.out.println();
		}
		System.out.println();
	
	}

}
