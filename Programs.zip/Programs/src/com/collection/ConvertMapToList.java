package com.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConvertMapToList {

	public static void main(String[] args) {

		Map<String,Integer> mp=new HashMap<String,Integer>();
		mp.put("bala", 1);
		mp.put("krishna", 2);
		mp.put("aks", 3);
		mp.put("kau", 4);
		
		List<String> lst=new ArrayList<>(mp.keySet());
		//System.out.println("List is"+lst);
		lst.forEach(System.out::println);
		
		List<Integer> lstint=new ArrayList<>(mp.values());
		
		//System.out.println("lst is "+lstint);
		lstint.forEach(System.out::println);
	}

}
