package com.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ArrayListExample {

	public static void main(String[] args) {

		List<String> names=new ArrayList<String>();  //List implementation classes: ArrayList,LinkedList,Vector
		names.add("bala");  // Insertion order preserved,allow null,uses array internally,worst for insertion or deletion
		names.add("ala");   // implements Random access interface and thats why it is fast for retrieval operation
							//default size:10,not synchronized ,high performance,1.2 version,allow duplicates also
		names.add("krishna");
		names.add(null);
		names.add(null);
		System.out.println(names.size());
		//Collections.sort(names); //To sort names in ascending order
		//Collections.reverse(names);//To reverse the list
		Collections.unmodifiableList(names);
		names.add("sfsf");
		System.out.println(names);
		
		List<Integer> marks=new LinkedList<>(); // insertion order preserved,best for insertion and deletion
		marks.add(10);                          // duplicates allowed,null can be inserted,uses doubly linked list
		marks.add(30);							// worst choice for retrieval operation
		Collections.addAll(marks, 34);
		marks.add(2, 60); //adds 60 at 3rd position
		System.out.println(marks);
		Collections.sort(marks);
		System.out.println(marks);
	}

}
