package com.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ReverseArrayList {

	public static void main(String[] args) {

		
		List<Integer> lst=new ArrayList<>();
		lst.add(1);
		lst.add(2);
		lst.add(3);
		lst.add(4);
		
		int a=3;
		if(lst.contains(a)){
			System.out.println("Index is:"+lst.indexOf(a));
		}
		
		Collections.reverse(lst);
		System.out.println("Reverse is:"+lst);
		
		
		LinkedList<Integer> lnk=new LinkedList<>();
		lnk.add(5);
		lnk.add(6);
		lst.addAll(lnk);
		
		System.out.println("Joining list and linked list:"+lst);
	}

}
