package com.core.java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SeriDesrExample {

	public static void main(String[] args) throws IOException, ClassNotFoundException {

		Student student = new Student();
		student.setId(1);
		student.setName("bala");
		student.setAge(25);
		FileOutputStream fos = new FileOutputStream(new File("N://f.txt"));  //object is serialized
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(student);
		oos.close();
		System.out.println("Object is Serialized");

		FileInputStream fis = new FileInputStream(new File("N://f.txt"));
		ObjectInputStream ois = new ObjectInputStream(fis); //object is deseriazled
		Student student2 = (Student) ois.readObject();
		System.out.println("Object is deserialized");
		System.out.println(student2);
		ois.close();
	}

}

class Student implements Serializable {
	private static final long serialVersionUID = -1803295620534404666L;

	int id;
	String name;
	int age;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + "]";
	}

}
