package com.core.java;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

public class Singleton implements Serializable {
	private static final long serialVersionUID = -7252229086925187731L;

	private static Singleton singleton = new Singleton(); // Eager Instantiation

	private Singleton() {

	}
	public static Singleton getInstance() {
		return singleton;
	}

}

class TestClass {

	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			FileNotFoundException, IOException {
		Singleton singleton = Singleton.getInstance();
		Singleton singleton1 = Singleton.getInstance();
		print("singleton", singleton);
		print("singleton1", singleton1);
		/*
		 * Class clzz=Class.forName("com.strings.Singleton");
		 * Constructor<Singleton> con=clzz.getDeclaredConstructor();
		 * con.setAccessible(true);
		 *  Singleton s3=con.newInstance();
		 */

		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("/name.ser"));
		oos.writeObject(singleton1);

		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("/name.ser"));
		Singleton s3 = (Singleton) ois.readObject();
		print("s3", s3);

	}

	private static void print(String string, Singleton singleton) {

		System.out.println(String.format("Object :%s,Hascode:%d", string, singleton.hashCode()));
	}
}
