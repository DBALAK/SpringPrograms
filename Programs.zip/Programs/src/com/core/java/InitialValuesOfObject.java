package com.core.java;

public class InitialValuesOfObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Emp em=new Emp();
     // em.setId(1);				//instance variable are intialized to 0 for integer,null for String,false for boolean
     // em.setName("krsihan");     //local variables are not initialized neither primitives nor object references
      em.show();
	}

}
class Emp{
	private int id; 
	String name;
	boolean isPassed;
	void show(){
		System.out.println(id+" "+name+" "+isPassed);
	}
}