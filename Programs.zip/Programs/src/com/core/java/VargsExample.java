package com.core.java;

public class VargsExample {
	
	public static void show(int ...args){
		int a=args.length;
		for(int i=0;i<a;i++){
			System.out.println(args[0]);
			System.out.println(args[1]);
		}
	}
	
	public static void main(String[] args) {
		show(10,20);
	}

}
