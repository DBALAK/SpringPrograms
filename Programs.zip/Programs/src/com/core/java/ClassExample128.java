package com.core.java;

public class ClassExample128 {
	
	public static void main(String[] args) {
		Integer i=-122; //Integer.valueOf(127)
		Integer i1=-122;
		System.out.println(i==i1);
		
		
		Integer i2=128;
		Integer i3=128;
		System.out.println(i2==i3); //it crates new object if we pass value beyond range -128 to 127
	}

}
