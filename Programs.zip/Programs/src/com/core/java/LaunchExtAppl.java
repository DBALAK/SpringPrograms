package com.core.java;

import java.io.IOException;

public class LaunchExtAppl {

	public static void main(String[] args) throws IOException {
		Runtime.getRuntime().exec("notepad.exe");
	}

}
