package com.core.java;

public final class ImmutableClass
{
    final String name;
    final int regNo;
 
    public ImmutableClass(String name,int regNo)  //final class,only getter method,once object is created cannot be modified
    {									//parameterized constructor,final variables, for thread safety we need immutable class
        this.name=name;
        this.regNo=regNo;
    }
    public String getName()
    {
        return name;
    }
    public int getRegNo()
    {
        return regNo;
    }
}
 
// Driver class
class Test
{
    public static void main(String args[])
    {
        ImmutableClass s = new ImmutableClass("ABC", 101);
        System.out.println(s.name);
        System.out.println(s.regNo);
 
        // Uncommenting below line causes error
        // s.regNo = 102;
    }
}