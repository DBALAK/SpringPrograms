package com.core.java;

import java.util.ArrayList;
import java.util.List;

public class ForEachExample {

	public static void main(String[] args) {

		String[] str={"ram","shyam","gita","sita"};
		
		//normal for loop
		System.out.println("Normal For Loop:");
		for(int i=0;i<str.length;i++)
		{
			System.out.println(str[i]);
		}
		
		//for each loop
		System.out.println("For Each loop:");
		for(String names:str){
			System.out.println(names);
		}
		
		System.out.println("Java 8 using lambda expression");
		List<String> gamesList = new ArrayList<String>();  
        gamesList.add("Football");  
        gamesList.add("Cricket");  
        gamesList.add("Chess");  
        gamesList.add("Hocky");  
        gamesList.forEach(games -> System.out.println(games));
        gamesList.forEach(System.out::println);
		
		
	}

}
