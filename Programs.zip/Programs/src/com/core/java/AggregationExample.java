package com.core.java;

public class AggregationExample {

	public static void main(String[] args) {
		//special form of association,one way relationship
		//both entities survive individually , has-a relationship

		
	}

}
