package com.core.java;

interface P {

}

class B {

	void show() {
		System.out.println("Hello");
	}
}

class C {
	public static void main(String[] args) {
		B obj = new B();
		if (obj instanceof P) // if B implements Marker inteface
											// then we get Hello o/p
			obj.show(); // if B doesnt implements Marker interface then No
						// permisiion is o/p
		else
			System.out.println("No Persmission");
	}
}
