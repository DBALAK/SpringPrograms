package com.core.java;

public class DepricatedMethod {

	@Deprecated
	public void show() {
		System.out.println("Deprecated method");
	}
}
class SubDepricatedMethod extends DepricatedMethod {

	public static void main(String[] args) {
		DepricatedMethod sm = new DepricatedMethod();
		sm.show();
	}
}
