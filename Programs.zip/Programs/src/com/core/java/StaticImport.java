package com.core.java;

import static java.lang.System.out;
public class StaticImport {
	
	public static void main(String[] args) {
		out.println("Hello");
	}

}
