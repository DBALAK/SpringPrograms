package com.core.java;

public class ConstructorChaining {

	ConstructorChaining() {

		this(10);
		System.out.println("in defaut construcutor");
	}

	ConstructorChaining(int i) {
		System.out.println("In param" + i);
	}

}

class MainCons {
	public static void main(String[] args) {
		ConstructorChaining c = new ConstructorChaining();
	}
}
