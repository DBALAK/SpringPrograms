package com.core.java;

public class SingletonUsingLazy {

	private static SingletonUsingLazy singletonUsingLazy;

	private SingletonUsingLazy() {
		System.out.println("Instance created");
	}

	public static synchronized SingletonUsingLazy getInstance() { // Singleton using lazy instantiation and threading
		if (singletonUsingLazy == null) {
			singletonUsingLazy = new SingletonUsingLazy();
		}
		return singletonUsingLazy;
	}
}
class MainSingleton {
	public static void main(String[] args) {

		Thread t1 = new Thread(new Runnable() {
			@Override
			public void run() {
				SingletonUsingLazy obj2 = SingletonUsingLazy.getInstance();
			}
		});
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				SingletonUsingLazy obj3 = SingletonUsingLazy.getInstance();
			}
		});
		t1.start();
		t2.start();
		// SingletonUsingLazy obj = SingletonUsingLazy.getInstance();
		// SingletonUsingLazy obj1 = SingletonUsingLazy.getInstance();

	}
}
