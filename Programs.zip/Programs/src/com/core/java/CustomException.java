package com.core.java;

public class CustomException {

	public static void main(String[] args) {
		int i = 15;
		try {
			if (i > 10) {
				throw new MyException("i cannot be less than 10");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

class MyException extends Exception {

	public MyException(String errorMsg) {
		super(errorMsg);
	}
}
