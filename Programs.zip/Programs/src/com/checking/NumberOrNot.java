package com.checking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class NumberOrNot {

	public static void main(String[] args) {
		String input = "";
		int inputInteger = 0;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the radius: ");
		try {
			input = br.readLine();
			inputInteger = Integer.parseInt(input);
		} catch (NumberFormatException e) {
			System.out.println("Please Enter An Integer");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		float area = (float) (3.14 * inputInteger * inputInteger);
		System.out.println("Area = " + area);
	}

}
