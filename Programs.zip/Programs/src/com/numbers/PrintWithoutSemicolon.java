package com.numbers;

public class PrintWithoutSemicolon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      if(System.out.printf("Hello")==null){
    	
      }
	}
	

}
