package com.numbers;

import java.util.Scanner;

public class CountNoOfDigits {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a;   //1234
		System.out.println("Enter  no");
		a=s.nextInt();
		System.out.println("No of digits");
		int count=0;
		while(a>0){
			a=a/10;
			count++;
		}
		System.out.println(count);
	}

}
