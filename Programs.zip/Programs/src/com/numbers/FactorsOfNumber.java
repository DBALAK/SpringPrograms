package com.numbers;

public class FactorsOfNumber {

	public static void main(String[] args) {

		int a=10;
		for(int i=1;i<=10;i++){
			if(a%i==0){
				System.out.println(i);
			}
		}
		
	}

}
