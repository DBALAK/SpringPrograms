package com.numbers;

public class NoFromOneToTen {
	public static void main(String[] args) {
		printnowithrecursion(1);
	}

	public static void printnowithrecursion(int n) {
		if (n <= 10) {
			System.out.println(n);
			printnowithrecursion(n + 1);
		}
	}
}
