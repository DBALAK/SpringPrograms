package com.numbers;

public class Armstrong {
	public static void main(String[] args) {
		int n = 153, s = 0, arm;
		arm = n;
		while (n > 0) {
			int r = n % 10;
			s = s + (r * r * r);
			n = n / 10;
		}
		if (s == arm)
			System.out.println("armstrong no.");
		else
			System.out.println("not armstrong no.");
	}

}
