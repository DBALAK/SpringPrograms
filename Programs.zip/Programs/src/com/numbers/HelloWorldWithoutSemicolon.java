package com.numbers;

public class HelloWorldWithoutSemicolon {
	public static void main(String[] args) {
			if(System.out.printf("Hello")==null){
				
			}
	}

}
