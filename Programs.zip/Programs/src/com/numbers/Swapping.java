package com.numbers;

public class Swapping {

	public static void main(String[] args) {

		int a = 4, b = 5;
		System.out.println("No before swapping a=" + a + ",b =" + b);
		int t= a;
		a = b;
		b = t;
		System.out.println("No. after swapping a=" + a + ",b=" + b);
		
		swapwithouttemporayvariable();
	}

	private static void swapwithouttemporayvariable() {
       int a=6,b=9;
       System.out.println("No. before swapping a=" + a + ",b=" + b);
		a=a+b; //a=9
		b=a-b;// b=9-4=5
		a=a-b;
		System.out.println("No. after swapping a=" + a + ",b=" + b);
		
	}

}
