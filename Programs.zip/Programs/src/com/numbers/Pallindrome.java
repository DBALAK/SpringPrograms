package com.numbers;

public class Pallindrome {

	public static void main(String[] args) {
		int n = 1234, reverse = 0, t;
		t = n;
		while (n != 0) {

			int s = n % 10;
			reverse = reverse * 10 + s;
			n = n / 10;
		}
		System.out.println(reverse);
		if (t == reverse)
			System.out.println("Pallindrome");
		else
			System.out.println("Not a pallindrome");

	}

}
