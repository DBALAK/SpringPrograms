package com.numbers;

public class PerfectNumber {
	public static void main(String[] args) {
       int a=6,s=0;
       for(int i=1;i<a;i++){
    	   if(a%i==0){
    		    s=s+i;
    	   }
       }
       
       if(s==a)
    	   System.out.println("Perfect no.");
       else
    	   System.out.println("Not perfect no.");
	}
}
