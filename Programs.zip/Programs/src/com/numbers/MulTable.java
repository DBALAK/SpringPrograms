package com.numbers;

import java.util.Scanner;

public class MulTable {

	public static void main(String[] args) {

		System.out.println("Enter no to get multiplication table:");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt(),table = 1;
		for(int i=1;i<=10;i++){
			 table=n*i;
			 System.out.printf("%d * %d =%d",n,i,table);
			 System.out.println();
		}
		
		
	}

}
