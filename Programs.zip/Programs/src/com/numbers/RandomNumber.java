package com.numbers;

import java.util.Random;

public class RandomNumber {

	public static void main(String[] args) {

		Random r=new Random();
		for(int i=0;i<5;i++){
			System.out.println(r.nextInt(9));
		}
	}

}
