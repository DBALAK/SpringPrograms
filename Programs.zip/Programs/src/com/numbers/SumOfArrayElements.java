package com.numbers;

public class SumOfArrayElements {
	public static void main(String[] args) {
		int a[] = {1,2,3,4,5};
		int sum=sumWithoutRecursion(a);
		int sum1= sumWithRecusion(a,5);
		System.out.println(sum);
		System.out.println(sum1);
	}

	private static int sumWithRecusion(int a[],int n) {
		if(n<=0)
			return 0;
		return (sumWithRecusion(a, n-1)+a[n-1]);
	}

	private static int sumWithoutRecursion(int a[]) {
	   int sum=0;
		for(int i=0;i<a.length;i++){
		   sum=sum+a[i];
	   }
		return sum;
	}

}
