package com.numbers;

public class PrimeOrNot {

	public static void main(String[] args) {

		int num = 29;
		boolean flag = true;
		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				flag = false;
				break;
			}
		}
		if (flag)
			System.out.println("Prime no");
		else
			System.out.println("Not a prime no.");
	}

}
