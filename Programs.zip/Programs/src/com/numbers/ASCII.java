package com.numbers;

public class ASCII {
	public static void main(String[] args) {
		for(int i=0;i<122;i++){
			System.out.printf("%d:%c",i,i);
			System.out.println();
		}
	}

}
