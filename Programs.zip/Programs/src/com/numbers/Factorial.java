package com.numbers;

public class Factorial {
	public static void main(String[] args) {

		int n = 5, fact = 1, i = 1;
		while (i <= n) {
			fact = fact * i;
			i++;
		}
		System.out.println("Factorial using while loop is :" + fact);
		
		fact=1;
		for(int j=1;j<=n;j++){
			fact=fact*j;
		}
		System.out.println("Factorial using for loop:"+fact);
		
		int factOfNo=factorial(6);
		System.out.println("Factorial using recursion"+factOfNo);
	}

	private static int factorial(int n) {
		// TODO Auto-generated method stub
		if(n==0||n==1)
			return 1;
		else
			return n*factorial(n-1);
	}

}
