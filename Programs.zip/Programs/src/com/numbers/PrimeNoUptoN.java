package com.numbers;

public class PrimeNoUptoN {

	public static void main(String[] args) {

	        for(int i=2;i<90;i++){
	            int j;
	            for( j=2;j<i;j++){
	                if(i%j ==0){
	                    break;
	                }

	            }if(j==i){
	                System.out.println(i);

	            }
	        }
		}
}
