package com.javaeight;

@FunctionalInterface
public interface Sum {
	void add(int a, int b);
}
