package com.javaeight;

public interface X {
	default void m3(){
		System.out.println("Inside m3");
	}
	
}
