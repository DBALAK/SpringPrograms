package com.javaeight;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LambdaExpForEach {

	public static void main(String[] args) {

		List<Integer> list=new ArrayList<>();
		list.add(12);
		list.add(16);
		
		System.out.println(list);
		
		System.out.print("Using for each:");
		list.forEach(s->System.out.println(s)); // -> is lambda exp
		
		List<String> lst=Arrays.asList("hello","baala");
		System.out.println(lst);
 		
	}

}
