package com.javaeight;

public class LambdaExp implements A{

	@Override
	public void myMethod() {
		System.out.println("Inside my myMethod");
	}

}
