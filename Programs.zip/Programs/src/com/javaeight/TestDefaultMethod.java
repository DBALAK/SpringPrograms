package com.javaeight;

public class TestDefaultMethod {

	public static void main(String[] args) {
		BA a = new BA();
		a.m3();
	}

}
