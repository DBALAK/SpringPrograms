package com.javaeight;

@FunctionalInterface
public interface A {

	void myMethod();

}
