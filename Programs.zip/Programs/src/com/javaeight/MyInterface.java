package com.javaeight;

public interface MyInterface {
	void myMethod(int i);
}
