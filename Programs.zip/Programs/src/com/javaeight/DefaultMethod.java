package com.javaeight;

public interface DefaultMethod {

	default void m3() {
		System.out.println("Inside m3");
	}
}
