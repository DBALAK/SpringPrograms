package com.javaeight;

public class TestSum {

	public static void main(String[] args) {

		Sum s = (x,y)->System.out.println("Sum is:"+(x+y));
		s.add(12, 30);
	}

}
