package com.javaeight;

public class MyMethodRef {

	public void method(int i) {
		System.out.println(i);
	}

	public static void main(String[] args) {

		MyInterface m = i -> System.out.println(i);
		m.myMethod(10);

		MyMethodRef mc = new MyMethodRef();
		MyInterface f1 = mc::method;
		f1.myMethod(20);
	}

}
