package com.javaeight;

public class TestLambda {

	public static void main(String[] args) {
		A l=()->System.out.println("Inside my method A");
		l.myMethod();
	}

}
