package com.javaeight;

public class BA implements DefaultMethod, X {

	public void m3() {
		System.out.println("Inside BA");
	}
}
