package com.strings;

public class StringReverseWithBreak {
	public static void main(String[] args) {
		String str = "balakrishn";
		for (int i = str.length() - 1; i >= 0; i--) {
			if (str.indexOf(str.charAt(i)) == str.lastIndexOf(str.charAt(i))) {
				System.out.print(str.charAt(i));
			} else {
				break;
			}
		}
		
	}

}
