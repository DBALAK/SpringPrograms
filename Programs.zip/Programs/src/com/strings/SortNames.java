package com.strings;

import java.util.Scanner;

public class SortNames {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size:");
		int size = s.nextInt();
		String str[] = new String[size];
		for (int i = 0; i < str.length; i++) {
			str[i] = s.next();
		}

		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < str.length - 1; j++) {
				if (str[j].compareToIgnoreCase(str[j + 1]) > 0) {
					String temp = str[j];
					str[j] = str[j + 1];
					str[j + 1] = temp;
				}
			}
		}

		System.out.println("Sorted name are:");
		for (int i = 0; i < str.length; i++)
			System.out.println(str[i]);

	}

}
