package com.strings;

import java.util.HashMap;

class NoOfOccurrenceOfCharacterInString {

	public static void main(String[] args) {
		characterCount("JavaisJava");
	}

	private static void characterCount(String input) {
		HashMap<Character, Integer> mp = new HashMap<Character, Integer>();
		char[] ary = input.toCharArray();

		for (char c : ary) {
			if (mp.containsKey(c)) {
				mp.put(c, mp.get(c) + 1);
			} else {
				mp.put(c, 1);
			}
		}
		System.out.println(mp);
	}
}
