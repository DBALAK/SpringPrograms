package com.strings;

class Reverse {

	public String reverseWithoutRecursion(String name){
		String reverseString="";
		for(int i=name.length()-1;i>=0;i--){
			reverseString=reverseString+name.charAt(i);
		}
		return reverseString;
	}
	public String reverseWithRecursion(String name){
		String reverse = "";
		if(name.length()<=1){
			return reverse;
		}else {
			return reverse+=reverseWithRecursion(name.substring(1))+name.charAt(0);
		}
	}
	
	
	public StringBuffer reverse(StringBuffer sb){
		StringBuffer sr=sb.reverse();
		return sr;
	}
}

public class StringReverse{
	public static void main(String[] args) {
		Reverse s=new Reverse();
		System.out.println("Without recursion:"+s.reverseWithoutRecursion("Hello"));
		System.out.println("With recursion:"+s.reverseWithRecursion("HelloWorld"));
		
		System.out.println("With recursion:"+s.reverse(new StringBuffer("HelloWorld")));
	}
}
