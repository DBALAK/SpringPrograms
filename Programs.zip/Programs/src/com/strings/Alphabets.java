package com.strings;

public class Alphabets {

	public static void main(String[] args) {

		for(char ch='a';ch<='z';ch++){
			System.out.println(ch);
		}
	}

}
