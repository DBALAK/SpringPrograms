package com.strings;

public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		remove("Hi I am there");
	}
	private static void remove(String string) {
		String str = string.replaceAll("\\s", "");
		System.out.println("Removing white spaces:" + str);
		
	}

}
