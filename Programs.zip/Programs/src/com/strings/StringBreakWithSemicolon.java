package com.strings;

public class StringBreakWithSemicolon {

	public static void main(String[] args) {

		String s = "programmingproblem", newString = "";
		int a[] = { 4, 3, 6 ,5}, t = 0;
		split(s, a, t, newString);

	}

	private static void split(String s, int[] a, int t, String newString) {
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum = sum + a[i];
		}

		if (sum > s.length()) {
			System.out.println("Cannot be computed..");
		} else {
			for (int i = 0; i < a.length; i++) {
				int c = a[i];
				int c1 = c + t;
				for (int j = t; j < c1; j++) {
					newString = newString + s.charAt(j);
					t++;
				}
				newString = newString + ";";
			}
			System.out.println("new String is: " + newString);
		}
	}
}
