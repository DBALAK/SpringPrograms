package com.strings;

public class CountVowelsConsonants {

	public static void main(String[] args) {

		String s="helloii";
		s=s.toUpperCase();
		char a[]=s.toCharArray();
		int vowels,consonants;
		vowels=consonants=0;
		for(int i=0;i<a.length;i++){
			if(a[i]=='E'||a[i]=='A'||a[i]=='I'||a[i]=='O'||a[i]=='U'){
				++vowels;
			}else
			{
				++consonants;
			}
		}
		System.out.println("vowels:"+vowels);
		System.out.println("consonants:"+consonants);
	}

}
