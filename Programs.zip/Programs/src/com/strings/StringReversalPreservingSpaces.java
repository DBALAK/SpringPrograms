package com.strings;

public class StringReversalPreservingSpaces {

	public static void main(String[] args) {
		String s = "my name is bala";
		String alteredString = "";
		for (int i = s.length() - 1; i >= 0; i--) {
			alteredString = alteredString + s.charAt(i);
		}
       System.out.println("Altered string is:"+alteredString);
	
	}
}
