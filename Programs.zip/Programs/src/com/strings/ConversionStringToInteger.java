package com.strings;

public class ConversionStringToInteger {

	public static void main(String[] args) {
		String s="1235";
		System.out.println("String to integer:");
		System.out.println(Integer.valueOf(s)+":"+Integer.parseInt(s));

		
		int i=1234;
		System.out.println("Integer to String:");
		System.out.println(String.valueOf(i)+":"+Integer.toString(i));

	}

}
