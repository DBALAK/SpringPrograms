package com.strings;

import java.util.Arrays;

public class SortCharInString {

	public static void main(String[] args) {

		String str="java";
		char a[]=str.toCharArray();
		Arrays.sort(a);
		//System.out.println(a);
		String sort=new String(a);
		System.out.println(sort);
		
	}

}
