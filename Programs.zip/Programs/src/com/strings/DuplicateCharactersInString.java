package com.strings;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DuplicateCharactersInString {

	public static void main(String[] args) {

		duplicate("JavaJ2EEiiii");
	}

	private static void duplicate(String string) {

		Map<Character,Integer> mp=new HashMap<Character,Integer>();
		char[] chr=string.toCharArray();
		
		for(char c:chr){
			
			if(mp.containsKey(c)){
				mp.put(c,mp.get(c)+1 );
			}
			else
				mp.put(c,1);
		}
		
		Set<Character> charsInString=mp.keySet();
		System.out.println("Duplicate characters in input string:"+string);
		
		for (Character ch : charsInString)
        {
            if(mp.get(ch) > 1)
            {
                System.out.println(ch +" : "+ mp.get(ch));
            }
        }
	}

}
