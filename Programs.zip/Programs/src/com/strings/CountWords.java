package com.strings;

public class CountWords {

	public static void main(String[] args) {

		String s = "Hello I m there";
		String s1[] = s.split(" ");
		System.out.println("Words count:"+s1.length);
		for(int i=0;i<s1.length;i++){
			System.out.println(s1[i]);
		}

	}

}
